package domain;

 /**
 * The class Predator extends animal
 */ 
public class Predator extends Animal {
	
	/** 
	 *
	 * Hunt
	 *
	 */
	public void hunt() { 
		System.out.println("Predator is hunting...");
	}
}
