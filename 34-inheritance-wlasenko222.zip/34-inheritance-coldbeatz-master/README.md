# Практична робота "Реалізація успадкування"

# Було змодельовано птицю

<img src="https://github.com/ppc-ntu-khpi/34-inheritance-coldbeatz/blob/master/images/content_17025.jpg"/>
<img src="https://github.com/ppc-ntu-khpi/34-inheritance-coldbeatz/blob/master/images/578767.jpg"/>

## UML діаграма
<img src="https://github.com/ppc-ntu-khpi/34-inheritance-coldbeatz/blob/master/images/Bird-Diagram.png"/>

## Результат
<img src="https://github.com/ppc-ntu-khpi/34-inheritance-coldbeatz/blob/master/images/Screenshot_23.png"/>
