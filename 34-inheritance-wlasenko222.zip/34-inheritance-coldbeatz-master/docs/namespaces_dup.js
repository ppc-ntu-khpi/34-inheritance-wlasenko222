var namespaces_dup =
[
    [ "domain", "namespacedomain.html", "namespacedomain" ],
    [ "test", "namespacetest.html", "namespacetest" ]
];