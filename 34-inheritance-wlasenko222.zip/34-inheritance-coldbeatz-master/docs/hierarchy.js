var hierarchy =
[
    [ "domain.Animal", "classdomain_1_1_animal.html", [
      [ "domain.Predator", "classdomain_1_1_predator.html", [
        [ "domain.Bird", "classdomain_1_1_bird.html", null ]
      ] ]
    ] ],
    [ "test.TestAnimal", "classtest_1_1_test_animal.html", null ]
];