var searchData=
[
  ['bird_31',['Bird',['../classdomain_1_1_bird.html#a6cb7720b61062681006b3ec8f4ffa216',1,'domain.Bird.Bird(String name, int age, int weight, String kind)'],['../classdomain_1_1_bird.html#a755da06c8d448706f50d5a66f74982d9',1,'domain.Bird.Bird(String name, int age, int weight)'],['../classdomain_1_1_bird.html#ac19be4f06f55a0e41d167c06f891741d',1,'domain.Bird.Bird()']]]
];
