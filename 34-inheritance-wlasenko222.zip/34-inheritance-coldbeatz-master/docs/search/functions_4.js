var searchData=
[
  ['hunt_34',['hunt',['../classdomain_1_1_bird.html#ad060bf9342c04ffc54db2110dd68e38d',1,'domain.Bird.hunt()'],['../classdomain_1_1_predator.html#ad00b41c1e8b3652e62fe8f365d3a737a',1,'domain.Predator.hunt()']]]
];
