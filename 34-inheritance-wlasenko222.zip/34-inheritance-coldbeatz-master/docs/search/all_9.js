var searchData=
[
  ['sleep_13',['sleep',['../classdomain_1_1_animal.html#ad168ff1deb4cf3e0628fa8ed6bdacc30',1,'domain::Animal']]],
  ['speak_14',['speak',['../classdomain_1_1_animal.html#a0070dca2022620de6da5c005e04609a6',1,'domain.Animal.speak()'],['../classdomain_1_1_bird.html#a68630ea690c4905757c570dea74903ab',1,'domain.Bird.speak()']]]
];
